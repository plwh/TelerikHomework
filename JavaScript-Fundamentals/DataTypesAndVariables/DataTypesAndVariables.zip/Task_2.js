// Problem 2: Create a string variable with quoted text in it.
// For example: `'How you doin'?', Joey said'.

var jsConsole;
var string = '"How you doin?", Joey said';

console.log(string);
jsConsole.writeLine(string);
